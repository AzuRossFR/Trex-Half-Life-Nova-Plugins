
ITEM.name = "Métal"
ITEM.model = Model("models/props_c17/TrapPropeller_Lever.mdl")
ITEM.description = "Un petit morceau de métal utile pour créer des choses."
ITEM.category = "TrexCraft"
