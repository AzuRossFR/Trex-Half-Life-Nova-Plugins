
LANGUAGE = {
	["CraftMissingFlag"] = "Il vous manque l'indicateur %s.",
	["CraftMissingTool"] = "Il vous manque un %s.",
	["CraftMissingItem"] = "Il vous manque : %s.",
	["CraftSuccess"] = "Vous avez créé %s avec succès.",

	["CraftTools"] = "OUTILS",
	["CraftRequirements"] = "EXIGENCES",
	["CraftResults"] = "RÉSULTATS",

	["cmdCraftRecipe"] = "Tentative d'élaboration d'une recette."
}
