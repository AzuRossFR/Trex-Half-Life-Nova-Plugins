local PLUGIN = PLUGIN
SCOREBOARD = SCOREBOARD or {}

PLUGIN.name = "UI (TAB)"
PLUGIN.description = "UI Reworked by Khall."
PLUGIN.author = "Khall"
PLUGIN.schema = "Any"