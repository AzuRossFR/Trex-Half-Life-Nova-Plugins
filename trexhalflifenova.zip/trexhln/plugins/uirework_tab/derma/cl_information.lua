hook.Add("CreateMenuButtons", "ixCharInfo", function(tabs)
end)