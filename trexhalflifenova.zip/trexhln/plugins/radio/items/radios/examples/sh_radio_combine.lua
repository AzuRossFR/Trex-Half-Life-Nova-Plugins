
ITEM.name = "Combine Radio"
ITEM.description = "A special encrypted radio that is biolocked. Only members of the Combine can use it."
ITEM.frequency = "combine"
ITEM.frequencyID = "combine"
ITEM.factionLock = {
	--[FACTION_SRVADMIN] = true,
	--[FACTION_OVERWATCH] = true,
	[FACTION_OTA] = true
}
