
ITEM.name = "Board Representitive Radio"
ITEM.description = "A special encrypted radio that has Union markings on it."
ITEM.frequency = "br"
ITEM.frequencyID = "br"
