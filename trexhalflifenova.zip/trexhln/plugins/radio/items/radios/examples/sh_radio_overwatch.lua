
ITEM.name = "Overwatch Radio"
ITEM.description = "A special encrypted radio that is biolocked. Only members of Overwatch can use it."
ITEM.frequency = "overwatch"
ITEM.frequencyID = "overwatch"
ITEM.factionLock = {
	--[FACTION_SRVADMIN] = true,
	--[FACTION_OVERWATCH] = true,
	[FACTION_OTA] = true
}
