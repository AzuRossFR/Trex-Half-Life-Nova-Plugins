
ITEM.name = "CWU-Industrial Radio"
ITEM.description = "An encrypted radio branded with the CWU logo, permanently tuned to the CWU-I subchannel."
ITEM.frequency = "cwu-i"
ITEM.frequencyID = "freq_cwui"
ITEM.stationaryCanAccess = false
