
ITEM.name = "UU Radio"
ITEM.description = "A special encrypted radio that requires a password to be used. It has a Union logo on it."
ITEM.frequency = "uu"
ITEM.frequencyID = "freq_uu"
ITEM.stationaryCanAccess = false
