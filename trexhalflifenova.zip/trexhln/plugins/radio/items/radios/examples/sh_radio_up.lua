
ITEM.name = "UC Radio"
ITEM.description = "A special encrypted radio that requires a password to be used. It has a Unity Congress logo on it."
ITEM.frequency = "uc"
ITEM.frequencyID = "freq_up"
ITEM.stationaryCanAccess = false
