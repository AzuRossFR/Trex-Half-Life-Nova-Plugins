
ITEM.name = "Medical Intercom"
ITEM.description = "A small communications terminal with a handset, transmitting to Union Medical staff."
ITEM.model = "models/props_office/office_phone.mdl"
ITEM.category = "Communication"
ITEM.frequencyID = "intercom_um"
