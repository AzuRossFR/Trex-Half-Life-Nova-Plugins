
LANGUAGE = {
	radioNoAccess = "Vous n'avez pas accès à ce canal!",
	radioNoChannel = "Vous n'êtes pas sur un canal valide!",
	radioChannelSet = "Vous avez réglé votre canal sur '%s'.",
	radioChannelSetSub = "Vous avez réglé votre chaîne sur '%s' (#%d).",
	radioChannelInvalid = "%s n'est pas un canal valide!",

	chatRadioing = "Radiodiffusion...",
}
