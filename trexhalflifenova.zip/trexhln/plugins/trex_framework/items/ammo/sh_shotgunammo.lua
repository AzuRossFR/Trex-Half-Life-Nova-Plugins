ITEM.name = "Munitions de fusil à pompe"
ITEM.model = "models/Items/BoxBuckshot.mdl"
ITEM.ammo = "buckshot" -- type of the ammo
ITEM.ammoAmount = 15 -- amount of the ammo
ITEM.description = "Cette boite contient %s munitions de fusil à pompe."
ITEM.category = "Munitions"
