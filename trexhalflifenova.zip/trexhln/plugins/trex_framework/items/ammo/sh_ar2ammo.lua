ITEM.name = "Munitions Principales"
ITEM.model = "models/Items/BoxSRounds.mdl"
ITEM.ammo = "ar2" -- type of the ammo
ITEM.ammoAmount = 100 -- amount of the ammo
ITEM.description = "Cette boite contient %s munitions principales."
ITEM.category = "Munitions"
ITEM.width = 1
ITEM.height = 1
ITEM.iconCam = {
	pos = Vector(107.02, 3.58, 13.1),
	ang = Angle(4.93, 181.98, 0),
	fov = 10.18
}
