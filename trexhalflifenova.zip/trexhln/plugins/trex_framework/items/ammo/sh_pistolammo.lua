ITEM.name = "Munitions de Pistolet"
ITEM.model = "models/Items/BoxSRounds.mdl"
ITEM.ammo = "pistol" -- type of the ammo
ITEM.ammoAmount = 90 -- amount of the ammo
ITEM.description = "Cette boite contient %s munitions de Pistolet."
ITEM.category = "Munitions"
ITEM.flag = "V"
