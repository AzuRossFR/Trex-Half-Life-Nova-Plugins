ITEM.name = "Munitions de 357"
ITEM.model = "models/Items/357ammobox.mdl"
ITEM.ammo = "tfa_ammo_357" -- type of the ammo
ITEM.ammoAmount = 90 -- amount of the ammo
ITEM.description = "Cette boite contient %s munitions de 357."
ITEM.category = "Munitions"
ITEM.flag = "V"
ITEM.rarity = 2
