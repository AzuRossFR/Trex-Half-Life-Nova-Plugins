ITEM.name = "Rounded Table"
ITEM.description = "Round Table"
ITEM.category = "Constructable"
ITEM.model = "models/Items/item_item_crate.mdl"
ITEM.prop = "models/props_c17/FurnitureTable001a.mdl"
ITEM.width = 2
ITEM.height = 2
