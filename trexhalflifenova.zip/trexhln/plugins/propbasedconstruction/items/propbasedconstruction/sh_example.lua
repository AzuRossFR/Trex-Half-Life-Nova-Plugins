ITEM.name = "THE MYTHICAL SKULL" -- the name of the item
ITEM.description = "A skull which you can hear incantations from." -- a general discription of the item for when players mouse over the item.
ITEM.category = "Constructable" -- The category this item falls under, this is mainly used for venders and other items
ITEM.model = "models/props_junk/cardboard_box002a.mdl" -- the model of the item when dropped and when inside the  
ITEM.prop = "models/gibs/agibs.mdl" -- the model of the item that you want placed
ITEM.width = 1 -- how wide the item is in the inv
ITEM.height = 1 -- how tall the item is in the inv
