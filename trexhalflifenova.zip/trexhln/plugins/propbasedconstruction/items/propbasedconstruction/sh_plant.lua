ITEM.name = "Potted Plant"
ITEM.description = "A potted Plant"
ITEM.category = "Constructable"
ITEM.model = "models/Items/item_item_crate.mdl"
ITEM.prop = "models/props_lab/cactus.mdl"
ITEM.width = 1
ITEM.height = 1
