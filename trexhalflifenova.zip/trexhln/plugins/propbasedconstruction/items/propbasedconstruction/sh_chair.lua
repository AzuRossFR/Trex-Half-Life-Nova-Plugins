ITEM.name = "Caisse de décontamination Combine"
ITEM.description = ""
ITEM.category = "Constructable"
ITEM.model = "models/hlvr/combine_hazardprops/combinehazardprops_crate.mdl"
ITEM.prop = "models/hlvr/combine_hazardprops/combinehazardprops_crate.mdl"
ITEM.width = 2
ITEM.height = 2
