LANGUAGE = {
	area = "Area",
	areas = "Areas",
	areaEditMode = "Area Edit Mode",
	areaNew = "New Area",
	areaAlreadyExists = "An area with this name already exists!",
	areaDoesntExist = "An area with that name doesn't exist!",
	areaInvalidType = "You have specified an invalid area type!",
	areaEditTip = "Click to start creating an area. Right click to exit.",
	areaFinishTip = "Click again to finish drawing the area. Right click to go back.",
	areaRemoveTip = "Press reload to remove the area you're currently in.",
	areaDeleteConfirm = "Are you sure you want to delete the area \"%s\"?",
	areaDelete = "Delete Area",

	cmdAreaEdit = "Enters area edit mode."
}