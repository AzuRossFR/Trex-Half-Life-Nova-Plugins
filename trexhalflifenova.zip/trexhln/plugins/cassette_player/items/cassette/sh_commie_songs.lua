ITEM.name = "Enregistrement de Breen"
ITEM.description = "Des vieux enregistrements."
ITEM.model = "models/willardnetworks/misc/idcard.mdl"
ITEM.cassette_options = {}
ITEM.cassette_options['vo/breencast/br_overwatch01.wav'] = {dur = 33}
ITEM.cassette_options['vo/breencast/br_overwatch02.wav'] = {dur = 170}
ITEM.cassette_options['vo/breencast/br_overwatch03.wav'] = {dur = 234}
ITEM.cassette_options['vo/breencast/br_overwatch04.wav'] = {dur = 104}
