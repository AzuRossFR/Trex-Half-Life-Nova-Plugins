local PLUGIN = PLUGIN

PLUGIN.name = "Tenues"
PLUGIN.author = "Trex"
PLUGIN.description = "."

ix.util.Include("cl_hooks.lua")
ix.util.Include("meta/sh_hazmat.lua", "shared")