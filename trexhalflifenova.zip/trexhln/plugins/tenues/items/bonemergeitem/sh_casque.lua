ITEM.name = "Cagoule Ghost"
ITEM.model = "models/eft_props/gear/facecover/facecover_zryachii_closed.mdl"
ITEM.width = 1 
ITEM.height = 1
ITEM.weight = 5
ITEM.description = [[Test item qui bonemerge
]]
ITEM.category = "Test Bonemerge"
ITEM.bonemerge = "models/eft_modular/gear/facecover/zryachii_balaklava_closed.mdl"
ITEM.slot = EQUIP_MASK
ITEM.attachement = "head"