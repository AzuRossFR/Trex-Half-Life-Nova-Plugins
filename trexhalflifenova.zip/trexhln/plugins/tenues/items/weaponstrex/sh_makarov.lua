ITEM.name = "Makarov"
ITEM.model = "models/weapons/tfa_ins2/w_pm.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.class = "tfa_ins2_pm"
ITEM.weight = 0.730
ITEM.description = [[Un Makarov est un pistolet semi-automatique compact de calibre 9x18 mm, d'origine russe, utilisé par la Division P
]]
ITEM.category = "TrexStudio"
ITEM.bDropOnDeath = true
ITEM.slot = EQUIP_ARMES -- SLOTS = ( EQUIP_MASK EQUIP_HEAD EQUIP_LEGS EQUIP_HANDS EQUIP_TORSO )
ITEM.rarity = 2
ITEM.rarityname = "Très Rare (Illégal)"
