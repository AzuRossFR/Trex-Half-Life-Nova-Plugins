ITEM.name = "Couteau Artisanale"
ITEM.model = "models/weapons/tfa_nmrih/w_me_kitknife.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.class = "tfa_nmrih_kknife"
ITEM.description = [[Un couteau artisanale fabriqué à la main.
]]
ITEM.category = "TrexCraft"
ITEM.weight = 0.310
ITEM.bDropOnDeath = true
ITEM.slot = EQUIP_ARMES
