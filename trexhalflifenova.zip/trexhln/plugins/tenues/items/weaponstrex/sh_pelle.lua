ITEM.name = "Pelle"
ITEM.model = "models/weapons/tfa_nmrih/W_me_spade.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.weight = 1.4 
ITEM.class = "cityworker_shovel"
ITEM.description = [[La pelle de fortification ronde est en acier au bore, ce qui garantit une solidité pour tous les travaux du BTP.
]]
ITEM.category = "TrexStudio"
ITEM.bDropOnDeath = true
ITEM.slot = EQUIP_PELLE 