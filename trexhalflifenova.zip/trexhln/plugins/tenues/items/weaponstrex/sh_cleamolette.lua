ITEM.name = "Clé à Molette"
ITEM.model = "models/weapons/tfa_nmrih/w_me_wrench.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.weight = 0.520 
ITEM.class = "cityworker_wrench"
ITEM.description = [[La clé à molette permet de visser ou dévisser des boulons ou vis à tête hexagonale de tailles différentes.
]]
ITEM.category = "TrexStudio"
ITEM.bDropOnDeath = true
ITEM.slot = EQUIP_CLE