ITEM.name = "HK-416 F"
ITEM.model = "models/weapons/w_nb_ins_416c.mdl"
ITEM.width = 4
ITEM.height = 2
ITEM.class = "tfa_ins2_416c"
ITEM.description = [[Le HK-416 F est une carabine d'assaut de calibre 5,56 mm, réputée pour sa fiabilité et sa précision. 

Elle est populaire auprès des forces spéciales et peut être personnalisée avec des accessoires.
]]
ITEM.weight = 3.7
ITEM.category = "TrexStudio"
ITEM.bDropOnDeath = true
ITEM.slot = EQUIP_ARMEP
ITEM.rarity = 2
ITEM.rarityname = "Très Rare (Illégal)"
