ITEM.name = "Matraque"
ITEM.model = "models/weapons/w_stunbaton.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.weight = 0.600
ITEM.class = "ix_stunstick"
ITEM.description = [[Une matraque est un instrument de défense ou de maintien de l'ordre, généralement constitué d'une poignée et d'une tige rigide utilisée pour frapper ou repousser un adversaire.
]]
ITEM.category = "TrexStudio"
ITEM.bDropOnDeath = true
ITEM.slot = EQUIP_AMNESIC -- SLOTS = ( EQUIP_MASK EQUIP_HEAD EQUIP_LEGS EQUIP_HANDS EQUIP_TORSO )
