ITEM.name = "MR - 96"
ITEM.model = "models/weapons/w_ins2_revolver_mr96.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.class = "tfa_ins2_mr96"
ITEM.description = [[Le MR 96 est un revolver à double action, reconnu pour sa conception soignée et sa performance fiable. 
]]
ITEM.category = "TrexStudio"
ITEM.weight = 1.3
ITEM.bDropOnDeath = true
ITEM.slot = EQUIP_ARMES
ITEM.rarity = 3
ITEM.rarityname = "Epique (Illégal)"