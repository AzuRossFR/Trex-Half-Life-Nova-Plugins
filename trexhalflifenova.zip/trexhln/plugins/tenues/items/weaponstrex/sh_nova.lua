ITEM.name = "Nova"
ITEM.model = "models/weapons/tfa_ins2/w_nova.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.weight = 3.5
ITEM.class = "tfa_ins2_nova"
ITEM.description = [[Le Nova est un fusil à pompe fabriqué par la société italienne Benelli. 

Il est conçu pour des applications militaires et tactiques, mais est également utilisé pour la chasse sportive et la défense personnelle.
]]
ITEM.category = "TrexStudio"
ITEM.bDropOnDeath = true
ITEM.slot = EQUIP_ARMEP -- SLOTS = ( EQUIP_MASK EQUIP_HEAD EQUIP_LEGS EQUIP_HANDS EQUIP_TORSO )
ITEM.rarity = 2
ITEM.rarityname = "Très Rare (Illégal)"
