ITEM.name = "CZ - 805"
ITEM.model = "models/weapons/tfa_ins2/w_cz805.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.class = "tfa_ins2_cz805"
ITEM.description = [[La CZ 805 est une carabine d'assaut modulaire développée par CZUB, une entreprise tchèque.

Elle est conçue pour être polyvalente et adaptable aux besoins des forces armées.
]]
ITEM.weight = 3.5
ITEM.category = "TrexStudio"
ITEM.bDropOnDeath = true
ITEM.slot = EQUIP_ARMEP
