ITEM.name = "Tuyau en métal"
ITEM.model = "models/props_canal/mattpipe.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.class = "tfa_nmrih_lpipe"
ITEM.description = [[Un gros tuyau en métal fabriquer à la main.
]]
ITEM.category = "TrexCraft"
ITEM.weight = 3.1
ITEM.bDropOnDeath = true
ITEM.slot = EQUIP_ARMES
