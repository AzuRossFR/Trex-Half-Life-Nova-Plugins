
ITEM.name = "Menottes"
ITEM.description = "Une paire de menotte utilisée pour restreindre un malfaiteur."
ITEM.category = "TrexStudio"
ITEM.model = "models/sterling/enhanced_handcuffs.mdl"
ITEM.class = "trex_menottes"
ITEM.slot = EQUIP_AMNESIC
ITEM.width = 1
ITEM.height = 1
ITEM.weight = 0.360 
ITEM.rarity = 0
ITEM.rarityname = "Commun (Illégal)"
