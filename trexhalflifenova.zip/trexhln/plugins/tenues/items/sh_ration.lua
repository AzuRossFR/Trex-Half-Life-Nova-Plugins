
ITEM.name = "Carton de Livraison"
ITEM.model = Model("models/props_junk/cardboard_box001a.mdl")
ITEM.description = "Une boîte qui contient du matériel à livré au poste de PC le plus proche."
ITEM.rarity = 1
ITEM.rarityname = "Atypique"
