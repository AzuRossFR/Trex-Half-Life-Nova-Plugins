ITEM.name = "Armure"
ITEM.model = "models/eft_props/gear/armor/ar_redut_t5.mdl"
ITEM.description = [[Une armure commune trouvable dans des endroits militarisé.
]]
ITEM.width = 1 
ITEM.height = 1
ITEM.weight = 1
ITEM.category = "TrexStudio"
ITEM.isEquipment = true
ITEM.maxArmor = 100;
ITEM.slot = EQUIP_SHIRT
ITEM.bonemerge = "models/eft_modular/gear/armor/cr/osprey_no_pouches.mdl"