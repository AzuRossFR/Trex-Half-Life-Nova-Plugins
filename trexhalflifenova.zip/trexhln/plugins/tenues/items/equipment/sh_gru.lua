ITEM.name = "Equipement Division P"
ITEM.description = "Un équipement pour vous battre contre la fondation"
ITEM.category = "TrexStudio"
ITEM.slot = EQUIP_MASK
ITEM.model = "models/props_junk/cardboard_box001a.mdl"
ITEM.replacements = "models/bratnik/soldier_fss.mdl"
