ITEM.name = "Casque Balistique"
ITEM.model = "models/player/helmet_achhc_black/achhc_black.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.description = [[Un casque balistique est un équipement de protection conçu pour protéger la tête contre les projectiles, les éclats et les impacts.
]]
ITEM.weight = 1.3
ITEM.rarity = 0
ITEM.category = "TrexStudio"
ITEM.slot = EQUIP_HEAD -- SLOTS = ( EQUIP_MASK EQUIP_HEAD EQUIP_LEGS EQUIP_HANDS EQUIP_TORSO )
ITEM.bodyGroups = { 
	[3] = 1,
	[4] = 1,
	[5] = 1,
	[6] = 1,
}
ITEM.Stats = {
	[HITGROUP_HEAD] = 25,
}