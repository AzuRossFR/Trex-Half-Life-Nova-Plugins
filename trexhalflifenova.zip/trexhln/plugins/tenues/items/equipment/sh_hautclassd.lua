ITEM.name = "T-Shirt Classe-D"
ITEM.model = "models/trex/items/classd_shirt.mdl"
ITEM.width = 1 
ITEM.height = 1
ITEM.weight = 0.155
ITEM.description = [[Un T-shirt de couleur orange ou un petit insigne y est brodé avec les initiales: SD.
]]
ITEM.category = "TrexStudio"
ITEM.slot = EQUIP_SHIRT
ITEM.bodyGroups = {
    [2] = 1,
}
