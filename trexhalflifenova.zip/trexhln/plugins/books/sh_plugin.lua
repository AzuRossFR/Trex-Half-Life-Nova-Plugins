--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

PLUGIN.name = "Books";
PLUGIN.description = "Adds books from Clockwork to HELIX.";
PLUGIN.author = "Adolphus";

ix.util.Include("cl_hooks.lua")