
FACTION.name = "Assemblée Central du Cartels"
FACTION.description = "A human Administrator advised by the Universal Union."
FACTION.color = Color(179, 0, 255)
FACTION.pay = 50
FACTION.image = ix.util.GetMaterial("trex/bannierefaction/acc_ban.png")
FACTION.icon = ix.util.GetMaterial("trex/logo/icon_cmb2.png")
FACTION.models = {
	{"models/player/suits/group1/male_01_open.mdl",0,"00000"},
	{"models/player/suits/group1/male_01_open_tie.mdl",0,"00000"},
	{"models/player/suits/group1/male_01_shirt.mdl",0,"00000"},
	{"models/player/suits/group1/male_01_shirt_tie.mdl",0,"00000"},
	{"models/player/suits/group1/male_02_open.mdl",0,"00000"},
	{"models/player/suits/group1/male_02_open_tie.mdl",0,"00000"},
	{"models/player/suits/group1/male_02_shirt.mdl",0,"00000"},
	{"models/player/suits/group1/male_02_shirt_tie.mdl",0,"00000"},
	{"models/player/suits/group1/male_03_open.mdl",0,"00000"},
	{"models/player/suits/group1/male_03_open_tie.mdl",0,"00000"},
	{"models/player/suits/group1/male_03_shirt.mdl",0,"00000"},
	{"models/player/suits/group1/male_03_shirt_tie.mdl",0,"00000"},
	{"models/player/suits/group1/male_04_open.mdl",0,"00000"},
	{"models/player/suits/group1/male_04_open_tie.mdl",0,"00000"},
	{"models/player/suits/group1/male_04_shirt.mdl",0,"00000"},
	{"models/player/suits/group1/male_04_shirt_tie.mdl",0,"00000"},
	{"models/player/suits/group1/male_05_open.mdl",0,"00000"},
	{"models/player/suits/group1/male_05_open_tie.mdl",0,"00000"},
	{"models/player/suits/group1/male_05_shirt.mdl",0,"00000"},
	{"models/player/suits/group1/male_05_shirt_tie.mdl",0,"00000"},
	{"models/player/suits/group1/male_06_open.mdl",0,"00000"},
	{"models/player/suits/group1/male_06_open_tie.mdl",0,"00000"},
	{"models/player/suits/group1/male_06_shirt.mdl",0,"00000"},
	{"models/player/suits/group1/male_06_shirt_tie.mdl",0,"00000"},
	{"models/player/suits/group1/male_07_open.mdl",0,"00000"},
	{"models/player/suits/group1/male_07_open_tie.mdl",0,"00000"},
	{"models/player/suits/group1/male_07_shirt.mdl",0,"00000"},
	{"models/player/suits/group1/male_07_shirt_tie.mdl",0,"00000"},
	{"models/player/suits/group1/male_08_open.mdl",0,"00000"},
	{"models/player/suits/group1/male_08_open_tie.mdl",0,"00000"},
	{"models/player/suits/group1/male_08_shirt.mdl",0,"00000"},
	{"models/player/suits/group1/male_08_shirt_tie.mdl",0,"00000"},
	{"models/player/suits/group1/male_09_open.mdl",0,"00000"},
	{"models/player/suits/group1/male_09_open_tie.mdl",0,"00000"},
	{"models/player/suits/group1/male_09_shirt.mdl",0,"00000"},
	{"models/player/suits/group1/male_09_shirt_tie.mdl",0,"00000"},
}
FACTION.isDefault = false
FACTION.isGloballyRecognized = true

FACTION_ADMIN = FACTION.index
