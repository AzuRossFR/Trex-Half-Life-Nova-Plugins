
FACTION.name = "Forces Transhumaines"
FACTION.description = "A transhuman Overwatch soldier produced by the Combine."
FACTION.color = Color(255, 208, 0)
FACTION.pay = 40
FACTION.models = {
	{"models/cultist/hl_a/combine_grunt/npc/combine_grunt.mdl",1,"0100101"},
}
FACTION.isDefault = false
FACTION.image = ix.util.GetMaterial("trex/bannierefaction/transhuman_ban.png")
FACTION.icon = ix.util.GetMaterial("trex/logo/icon_fs.png")
FACTION.isGloballyRecognized = true
FACTION.runSounds = {[0] = "NPC_CombineS.RunFootstepLeft", [1] = "NPC_CombineS.RunFootstepRight"}
FACTION.taglines = {
	"leader",
	"flash",
	"ranger",
	"hunter",
	"blade",
	"scar",
	"hammer",
	"sweeper",
	"swift",
	"fist",
	"sword",
	"savage",
	"tracker",
	"slash",
	"razor",
	"stab",
	"spear",
	"striker",
	"dagger"
}

function FACTION:GetDefaultName(ply)
	return "s24:GrT°" .. string.upper(self.taglines[math.random(1, #self.taglines)]) .. "." .. Schema:ZeroNumber(math.random(1000, 9999), 4), true
end


function FACTION:OnCharacterCreated(client, character)
	local inventory = character:GetInventory()

	inventory:Add("pistol", 1)
	inventory:Add("pistolammo", 2)

	inventory:Add("ar2", 1)
	inventory:Add("ar2ammo", 2)
end

function FACTION:OnTransferred(character)
	character:SetName(self:GetDefaultName())
	character:SetModel(self.models[1])
end

function FACTION:OnNameChanged(client, oldValue, value)
	local character = client:GetCharacter()

	if (!Schema:IsCombineRank(oldValue, "OWS") and Schema:IsCombineRank(value, "OWS")) then
		character:JoinClass(CLASS_OWS)
	elseif (!Schema:IsCombineRank(oldValue, "EOW") and Schema:IsCombineRank(value, "EOW")) then
		character:JoinClass(CLASS_EOW)
	end
end

FACTION_OTA = FACTION.index
