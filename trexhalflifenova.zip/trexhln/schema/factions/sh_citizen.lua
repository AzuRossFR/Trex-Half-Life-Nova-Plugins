FACTION.name = "Citoyen"
FACTION.image = ix.util.GetMaterial("trex/bannierefaction/citoyen_ban.png")
FACTION.icon = ix.util.GetMaterial("trex/logo/icon_citoyen.png")
FACTION.description = ""
FACTION.color = Color(196, 90, 90)
FACTION.isDefault = true
FACTION.models = {
	{"models/earl_rp/citizens/player/male_01.mdl",0,"00000"},
	{"models/earl_rp/citizens/player/male_02.mdl",0,"00000"},
	{"models/earl_rp/citizens/player/male_03.mdl",0,"00000"},
	{"models/earl_rp/citizens/player/male_04.mdl",0,"00000"},
	{"models/earl_rp/citizens/player/male_05.mdl",0,"00000"},
	{"models/earl_rp/citizens/player/male_06.mdl",0,"00000"},
	{"models/earl_rp/citizens/player/male_07.mdl",0,"00000"},
	{"models/earl_rp/citizens/player/male_08.mdl",0,"00000"},
	{"models/earl_rp/citizens/player/male_09.mdl",0,"00000"},
	{"models/earl_rp/citizens/player/female_01.mdl",0,"00000"},
	{"models/earl_rp/citizens/player/female_02.mdl",0,"00000"},
	{"models/earl_rp/citizens/player/female_04.mdl",0,"00000"},
	{"models/earl_rp/citizens/player/female_06.mdl",0,"00000"},
	{"models/earl_rp/citizens/player/female_19.mdl",0,"00000"},
	{"models/earl_rp/citizens/player/female_bms_1.mdl",0,"00000"},
	{"models/earl_rp/citizens/player/female_bms_2.mdl",0,"00000"},
}

function FACTION:OnCharacterCreated(client, character)
	local id = Schema:ZeroNumber(math.random(1, 99999), 5)
	local inventory = character:GetInventory()

	character:SetData("cid", id)

	inventory:Add("suitcase", 1)
	inventory:Add("cid", 1, {
		name = character:GetName(),
		id = id
	})
end

FACTION_CITIZEN = FACTION.index