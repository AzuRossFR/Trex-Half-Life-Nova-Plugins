CLASS.name = "Civil Worker's Union"
CLASS.faction = FACTION_CITIZEN

function CLASS:CanSwitchTo(client)
	return false
end

CLASS_CWU = CLASS.index